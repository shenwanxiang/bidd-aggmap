
from aggmap.map import AggMap
from joblib import load as loadmap

__version__ = '1.1.0'